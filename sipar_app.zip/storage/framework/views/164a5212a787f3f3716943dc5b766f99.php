
<?php $__env->startSection('title', 'Pencarian'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-head">
    <div>
        <h1>Hasil Pencarian</h1>
        <p><?php echo e($term !== '' ? 'Hasil untuk “'.$term.'”' : 'Masukkan kata kunci pada kolom pencarian.'); ?></p>
    </div>
</div>

<?php if($term !== ''): ?>
    <div class="row g-3">
        <div class="col-xl-6">
            <section class="surface p-3 p-md-4 h-100">
                <h2 class="panel-title mb-3">Alat <span class="text-muted">(<?php echo e($equipment->count()); ?>)</span></h2>
                <?php $__empty_1 = true; $__currentLoopData = $equipment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="d-flex justify-content-between gap-3 border-bottom py-2">
                        <div><strong><?php echo e($item->nama_alat); ?></strong><div class="panel-subtitle"><?php echo e($item->kode_alat); ?> · <?php echo e($item->kategori->nama_kategori); ?></div></div>
                        <a class="btn btn-light btn-sm align-self-center" href="<?php echo e($isAdmin ? route('admin.equipment', ['q' => $item->kode_alat]) : route('catalog', ['q' => $item->kode_alat])); ?>">Buka</a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted mb-0">Alat tidak ditemukan.</p>
                <?php endif; ?>
            </section>
        </div>

        <?php if($isAdmin): ?>
            <div class="col-xl-6">
                <section class="surface p-3 p-md-4 h-100">
                    <h2 class="panel-title mb-3">Siswa <span class="text-muted">(<?php echo e($students->count()); ?>)</span></h2>
                    <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="border-bottom py-2"><strong><?php echo e($student->nama); ?></strong><div class="panel-subtitle"><?php echo e($student->nis_nip); ?> · <?php echo e($student->email); ?></div></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-muted mb-0">Siswa tidak ditemukan.</p>
                    <?php endif; ?>
                </section>
            </div>
        <?php endif; ?>

        <div class="col-12">
            <section class="surface p-3 p-md-4">
                <h2 class="panel-title mb-3">Transaksi <span class="text-muted">(<?php echo e($loans->count()); ?>)</span></h2>
                <?php $__empty_1 = true; $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="d-flex flex-wrap justify-content-between gap-2 border-bottom py-2">
                        <div>
                            <strong>PJM-<?php echo e(str_pad($loan->id_peminjaman, 5, '0', STR_PAD_LEFT)); ?> · <?php echo e($loan->status); ?></strong>
                            <div class="panel-subtitle"><?php echo e($loan->detail->pluck('alat.nama_alat')->filter()->join(', ') ?: $loan->keperluan); ?></div>
                            <?php if($isAdmin): ?><div class="panel-subtitle"><?php echo e($loan->user?->nama); ?> · <?php echo e($loan->user?->nis_nip); ?></div><?php endif; ?>
                        </div>
                        <a class="btn btn-light btn-sm align-self-center" href="<?php echo e($isAdmin ? route('admin.reports') : route('loans.mine')); ?>">Lihat transaksi</a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted mb-0">Transaksi tidak ditemukan.</p>
                <?php endif; ?>
            </section>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sipar_app\resources\views/search/index.blade.php ENDPATH**/ ?>