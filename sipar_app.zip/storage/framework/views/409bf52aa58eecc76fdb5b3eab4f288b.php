
<?php $__env->startSection('title', 'Katalog Alat'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-head"><div><h1>Katalog Alat</h1><p>Temukan alat praktik yang tersedia di laboratorium RPL.</p></div><button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#scanModal"><i class="bi bi-qr-code-scan me-1"></i>Pindai QR</button></div>
<form method="get" class="surface p-2 mb-3 d-flex gap-2"><input class="form-control border-0" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari nama atau kode alat..."><button class="btn btn-primary" type="submit"><i class="bi bi-search"></i></button></form>
<form method="post" action="<?php echo e(route('loans.create')); ?>" id="loan-request-form"><?php echo csrf_field(); ?>
<div class="row g-3"><?php $__empty_1 = true; $__currentLoopData = $equipment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><div class="col-sm-6 col-xl-4"><article class="surface card-item h-100"><div class="d-flex align-items-start gap-3"><span class="equipment-icon"><i class="bi bi-tools"></i></span><div class="flex-grow-1"><span class="badge-status <?php echo e(strtolower($item->status_alat) === 'tersedia' ? 'status-tersedia' : 'status-'.strtolower($item->status_alat)); ?>"><?php echo e($item->status_alat); ?></span><h2 class="panel-title mt-2"><?php echo e($item->nama_alat); ?></h2><div class="panel-subtitle"><?php echo e($item->kode_alat); ?> · <?php echo e($item->kategori->nama_kategori); ?></div></div></div><div class="d-flex justify-content-between align-items-center border-top mt-3 pt-3"><label class="d-flex align-items-center gap-2 text-muted"><input class="form-check-input equipment-select m-0" type="checkbox" name="items[<?php echo e($item->id_alat); ?>][id_alat]" value="<?php echo e($item->id_alat); ?>" data-equipment="<?php echo e($item->id_alat); ?>" <?php if(old('items.'.$item->id_alat.'.id_alat')): echo 'checked'; endif; ?> <?php if($item->status_alat !== 'Tersedia' || $item->stok_tersedia < 1): echo 'disabled'; endif; ?>> Pilih · stok <strong class="text-dark"><?php echo e($item->stok_tersedia); ?></strong></label><input class="form-control equipment-quantity" style="width:82px" type="number" name="items[<?php echo e($item->id_alat); ?>][jumlah]" value="<?php echo e(old('items.'.$item->id_alat.'.jumlah',1)); ?>" min="1" max="<?php echo e($item->stok_tersedia); ?>" aria-label="Jumlah <?php echo e($item->nama_alat); ?>" <?php if(!$item->stok_tersedia || !old('items.'.$item->id_alat.'.id_alat')): echo 'disabled'; endif; ?>></div></article></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="col-12"><div class="surface p-5 text-center text-muted">Alat tidak ditemukan.</div></div><?php endif; ?></div>
<?php if($equipment->count()): ?><section class="surface p-3 p-md-4 mt-3"><div class="d-flex justify-content-between align-items-center mb-3"><div><h2 class="panel-title">Detail pengajuan</h2><div class="panel-subtitle">Pilih satu atau beberapa alat di atas.</div></div><span class="badge-status status-dipinjam" id="selected-count">0 alat dipilih</span></div><div class="row g-3"><div class="col-6 col-md-3"><label class="form-label">Tanggal pinjam</label><input class="form-control" type="date" name="tanggal_pinjam" min="<?php echo e(now()->toDateString()); ?>" value="<?php echo e(old('tanggal_pinjam')); ?>" required></div><div class="col-6 col-md-3"><label class="form-label">Rencana kembali</label><input class="form-control" type="date" name="tanggal_kembali_rencana" min="<?php echo e(now()->toDateString()); ?>" value="<?php echo e(old('tanggal_kembali_rencana')); ?>" required></div><div class="col-12 col-md-6"><label class="form-label">Keperluan</label><textarea class="form-control" name="keperluan" rows="2" required placeholder="Jelaskan keperluan alat praktik..."><?php echo e(old('keperluan')); ?></textarea></div><div class="col-12 d-flex justify-content-end"><button class="btn btn-primary" type="submit"><i class="bi bi-send me-1"></i>Kirim pengajuan</button></div></div></section><?php endif; ?>
<div class="mt-3"><?php echo e($equipment->links()); ?></div></form>
<div class="modal fade" id="scanModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h2 class="modal-title fs-6 fw-bold">Pindai QR alat</h2><button class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button></div><div class="modal-body"><div id="student-reader" class="qr-box"></div><div id="scan-result" class="mt-3 text-center text-muted"></div></div></div></div></div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
<script>
const studentReader = document.getElementById('student-reader');
let scanner;
function updateSelectionCount() {
    const count = [...document.querySelectorAll('.equipment-select:checked')].length;
    document.getElementById('selected-count').textContent = `${count} alat dipilih`;
}
document.querySelectorAll('.equipment-select').forEach(checkbox => {
    const quantity = checkbox.closest('article').querySelector('.equipment-quantity');
    checkbox.addEventListener('change', () => { quantity.disabled = !checkbox.checked; updateSelectionCount(); });
});
updateSelectionCount();
document.getElementById('scanModal').addEventListener('shown.bs.modal', async () => {
    if (!window.Html5Qrcode) { document.getElementById('scan-result').textContent = 'Pemindai tidak tersedia. Periksa koneksi internet.'; return; }
    scanner = new Html5Qrcode('student-reader');
    try { await scanner.start({facingMode:'environment'}, {fps:10, qrbox:{width:210,height:210}}, async token => {
        await scanner.stop();
        const result = document.getElementById('scan-result');
        try {
            const response = await fetch(`<?php echo e(url('/katalog/qr')); ?>/${encodeURIComponent(token)}`, {headers:{Accept:'application/json'}});
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || 'QR tidak dikenali.');
            const nameElement = document.createElement('strong');
            nameElement.textContent = data.nama;
            const detailsElement = document.createElement('div');
            detailsElement.textContent = `${data.kode} · ${data.kategori}`;
            const stockElement = document.createElement('div');
            stockElement.textContent = `Stok: ${data.stok} · ${data.status}`;
            result.replaceChildren(nameElement, detailsElement, stockElement);
            const selection = document.querySelector(`.equipment-select[data-equipment="${data.id_alat}"]`);
            if (selection && !selection.disabled) {
                selection.checked = true;
                selection.dispatchEvent(new Event('change'));
                selection.closest('article').scrollIntoView({behavior:'smooth',block:'center'});
            } else {
                document.querySelector('input[name="q"]').value = data.kode;
                document.querySelector('form[method="get"]').requestSubmit();
            }
        } catch (error) { result.textContent = error.message; }
    }); } catch { document.getElementById('scan-result').textContent = 'Izinkan akses kamera untuk memindai QR.'; }
});
document.getElementById('scanModal').addEventListener('hidden.bs.modal', () => { if (scanner?.isScanning) scanner.stop(); scanner = null; });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sipar_app\resources\views/catalog.blade.php ENDPATH**/ ?>