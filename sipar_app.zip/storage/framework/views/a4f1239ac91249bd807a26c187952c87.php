
<?php $__env->startSection('title','Data Siswa'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-head">
	<div><h1>Data Siswa</h1><p>Kelola akun siswa yang dapat mengajukan alat.</p></div>
	<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newStudent"><i class="bi bi-person-plus me-1"></i>Tambah siswa</button>
</div>

<section class="surface">
	<div class="table-responsive">
		<table class="table">
			<thead><tr><th>Nama</th><th>NIS</th><th>Email</th><th>Terdaftar</th><th>Aksi</th></tr></thead>
			<tbody>
				<?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<tr>
						<td><strong><?php echo e($student->nama); ?></strong></td>
						<td><?php echo e($student->nis_nip); ?></td>
						<td><?php echo e($student->email); ?></td>
						<td><?php echo e($student->created_at->format('d M Y')); ?></td>
						<td>
							<div class="d-flex gap-1">
								<button class="btn btn-light btn-sm" type="button" title="Ubah data siswa" aria-label="Ubah siswa <?php echo e($student->nama); ?>" data-bs-toggle="modal" data-bs-target="#editStudent-<?php echo e($student->id_user); ?>"><i class="bi bi-pencil"></i></button>
								<form method="post" action="<?php echo e(route('admin.students.delete', $student)); ?>" onsubmit="return confirm('Hapus akun siswa ini?')">
									<?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
									<button class="btn btn-light btn-sm text-danger" type="submit" title="Hapus siswa <?php echo e($student->nama); ?>" aria-label="Hapus siswa <?php echo e($student->nama); ?>"><i class="bi bi-trash"></i></button>
								</form>
							</div>
							<?php ($keepEditInput = $errors->any() && (string) old('_student_id') === (string) $student->id_user); ?>
							<div class="modal fade" id="editStudent-<?php echo e($student->id_user); ?>" tabindex="-1" aria-labelledby="editStudentLabel-<?php echo e($student->id_user); ?>" aria-hidden="true">
								<div class="modal-dialog modal-dialog-centered student-edit-dialog">
									<form class="modal-content" method="post" action="<?php echo e(route('admin.students.update', $student)); ?>">
										<?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
										<input type="hidden" name="_student_id" value="<?php echo e($student->id_user); ?>">
										<div class="modal-header">
											<div>
												<h2 class="modal-title fs-6 fw-bold" id="editStudentLabel-<?php echo e($student->id_user); ?>">Ubah data siswa</h2>
												<div class="text-muted small"><?php echo e($student->nis_nip); ?></div>
											</div>
											<button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Tutup"></button>
										</div>
										<div class="modal-body">
											<label class="form-label" for="student-name-<?php echo e($student->id_user); ?>">Nama</label>
											<input class="form-control mb-3" id="student-name-<?php echo e($student->id_user); ?>" name="nama" value="<?php echo e($keepEditInput ? old('nama', $student->nama) : $student->nama); ?>" required maxlength="120">
											<label class="form-label" for="student-nis-<?php echo e($student->id_user); ?>">NIS</label>
											<input class="form-control mb-3" id="student-nis-<?php echo e($student->id_user); ?>" name="nis_nip" value="<?php echo e($keepEditInput ? old('nis_nip', $student->nis_nip) : $student->nis_nip); ?>" required maxlength="30">
											<label class="form-label" for="student-email-<?php echo e($student->id_user); ?>">Email</label>
											<input class="form-control mb-3" id="student-email-<?php echo e($student->id_user); ?>" name="email" type="email" value="<?php echo e($keepEditInput ? old('email', $student->email) : $student->email); ?>" required maxlength="255">
											<label class="form-label" for="student-password-<?php echo e($student->id_user); ?>">Password baru (opsional)</label>
											<input class="form-control" id="student-password-<?php echo e($student->id_user); ?>" name="password" type="password" minlength="8" autocomplete="new-password">
											<div class="form-text">Kosongkan jika password tidak ingin diubah.</div>
										</div>
										<div class="modal-footer">
											<button class="btn btn-light" type="button" data-bs-dismiss="modal">Batal</button>
											<button class="btn btn-primary" type="submit"><i class="bi bi-check2 me-1"></i>Simpan perubahan</button>
										</div>
									</form>
								</div>
							</div>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<tr><td colspan="5" class="text-center text-muted py-4">Belum ada akun siswa.</td></tr>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
	<div class="p-3"><?php echo e($students->links()); ?></div>
</section>

<div class="modal fade" id="newStudent" tabindex="-1" aria-labelledby="newStudentLabel" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered student-edit-dialog">
		<form class="modal-content" method="post" action="<?php echo e(route('admin.students.store')); ?>">
			<?php echo csrf_field(); ?>
			<div class="modal-header">
				<h2 class="modal-title fs-6 fw-bold" id="newStudentLabel">Tambah akun siswa</h2>
				<button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Tutup"></button>
			</div>
			<div class="modal-body">
				<label class="form-label" for="new-student-name">Nama lengkap</label>
				<input class="form-control mb-3" id="new-student-name" name="nama" required maxlength="120">
				<label class="form-label" for="new-student-nis">NIS</label>
				<input class="form-control mb-3" id="new-student-nis" name="nis_nip" required maxlength="30">
				<label class="form-label" for="new-student-email">Email</label>
				<input class="form-control mb-3" id="new-student-email" type="email" name="email" required maxlength="255">
				<label class="form-label" for="new-student-password">Password awal</label>
				<input class="form-control" id="new-student-password" type="password" name="password" minlength="8" autocomplete="new-password" required>
			</div>
			<div class="modal-footer">
				<button class="btn btn-light" type="button" data-bs-dismiss="modal">Batal</button>
				<button class="btn btn-primary" type="submit">Buat akun</button>
			</div>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
	<script>
		<?php if($errors->any() && old('_student_id')): ?>
			const failedStudentModal = document.getElementById('editStudent-<?php echo e(old('_student_id')); ?>');
			if (failedStudentModal) bootstrap.Modal.getOrCreateInstance(failedStudentModal).show();
		<?php endif; ?>
	</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sipar_app\resources\views/admin/students.blade.php ENDPATH**/ ?>